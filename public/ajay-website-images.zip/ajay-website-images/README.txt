WEBSITE IMAGE PACK — where to use each file
===========================================
All files are .webp, all under 200 KB, all ready to upload as-is.
Folder 1 = CONTENT (normal photos).  Folder 2 = BACKGROUNDS (dark overlay already baked in, white text will read on top).

/content
  01-hero-founder-walking.webp   1672x941   Homepage hero (if you do NOT overlay text)
  02-about-banner-office.webp    1672x941   Top of the About page
  03-founder-portrait.webp       1122x1402  Founder / leadership section
  04-headshot-dark.webp          1200x1200  Main headshot, also LinkedIn
  05-culture-founder-desk.webp   1024x1280  Culture / "Why us" section
  06-contact-boardroom.webp      1024x1280  Contact / Book-a-consult section
  07-spare-boardroom-sunset.webp 1536x1024  Spare landscape
  08-spare-team-openplan.webp    1024x1280  Spare portrait
  09-thumb-headshot-square.webp   800x800   Team card thumbnail
  10-thumb-portrait-square.webp   800x800   Team card thumbnail (alt)
  11-og-share-preview.webp       1200x630   Social link preview (og:image meta tag)

/backgrounds  (text-safe area noted)
  bg-01-hero-corridor.webp       1672x941   Homepage hero      -> text on the RIGHT
  bg-02-services-boardroom.webp  1672x941   Services section   -> text on the RIGHT
  bg-03-cta-sunset.webp          1536x864   Call-to-action band-> text on the RIGHT
  bg-04-testimonial-dark.webp    1254x706   Testimonial/quote  -> text on the LEFT
  bg-05-hero-mobile.webp         1024x1365  Mobile hero (3:4)  -> text at the BOTTOM
  bg-06-careers-openplan.webp    1024x576   Careers section    -> text on the LEFT

HOW TO USE A BACKGROUND (example CSS)
-------------------------------------
.hero {
  background-image: url('/images/backgrounds/bg-01-hero-corridor.webp');
  background-size: cover;
  background-position: center;
  min-height: 80vh;
  display: flex; align-items: center; justify-content: flex-end;  /* text on the right */
  color: #fff;
}
@media (max-width: 768px) {
  .hero { background-image: url('/images/backgrounds/bg-05-hero-mobile.webp'); }
}

Always add alt text, e.g. alt="Ajay Krishna Reddy, Founder"
Add loading="lazy" to every image EXCEPT the hero.

ONE WARNING
-----------
The wall signs and mugs in these photos have AI-generated slogans baked in
("Better Ideas Brighter Future", "Discipline Creates Freedom", etc).
That is not your real branding and cannot be edited later. Put YOUR real tagline
as HTML text on top of the background images, and crop wall text out where it shows.
